# WebStorm Essentials Debugging

Sample code for the WebStorm Essentials Chapter 7

To install dependencies run 
    
    npm install

Serve by running 
    
    grunt serve
    